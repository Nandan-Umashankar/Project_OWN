package com.idc.dashboard.model;

public class SRM_REQEUST {
	private int active;
	private int queued;
	public int getActive() {
		return active;
	}
	public void setActive(int active) {
		this.active = active;
	}
	public int getQueued() {
		return queued;
	}
	public void setQueued(int queued) {
		this.queued = queued;
	}

}
