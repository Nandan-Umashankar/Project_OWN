package com.idc.dashboard.model;

import java.util.List;

public class OrderTypeAndCount {
	private List<String> orderType;
	private List<Integer> orderCount;
	public List<String> getOrderType() {
		return orderType;
	}
	public void setOrderType(List<String> orderType) {
		this.orderType = orderType;
	}
	public List<Integer> getOrderCount() {
		return orderCount;
	}
	public void setOrderCount(List<Integer> orderCount) {
		this.orderCount = orderCount;
	}
}
