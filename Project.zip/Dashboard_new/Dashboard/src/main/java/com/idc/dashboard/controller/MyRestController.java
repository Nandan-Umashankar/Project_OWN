package com.idc.dashboard.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.idc.dashboard.model.OrderTypeAndCount;
import com.idc.dashboard.model.TotalOrderCount;
import com.idc.dashboard.services.UserService;
import com.idc.dashboard.services.UserServiceImpl;

@RestController
public class MyRestController {
	
	UserService userService = new UserServiceImpl();
	
	List<Object> order_stat = new ArrayList<>();
	
	List<Object> allReport = new ArrayList<Object>();
	
	OrderTypeAndCount orderTypeAndCount = new OrderTypeAndCount();
	
	TotalOrderCount totalOrderCount = new TotalOrderCount();
 
	@PostMapping("/api/reports")
	public List<Object> getReports() {
		order_stat = userService.getReports();
		orderTypeAndCount = userService.getCountBasedOnOrderType();
		allReport.add(order_stat);
		allReport.add(orderTypeAndCount);
		totalOrderCount = userService.getTotalOrderCount();
		allReport.add(totalOrderCount);
		System.out.println(order_stat);
		System.out.println(orderTypeAndCount.getOrderType());
		return allReport;
	}

}
