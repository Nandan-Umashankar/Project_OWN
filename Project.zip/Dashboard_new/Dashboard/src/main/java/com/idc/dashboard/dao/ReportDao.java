package com.idc.dashboard.dao;

import java.util.List;

import com.idc.dashboard.model.OrderTypeAndCount;
import com.idc.dashboard.model.TotalOrderCount;

public interface ReportDao {
	List<Object> getReportsAll();

	OrderTypeAndCount getCountBasedOnOrderType();

	TotalOrderCount getTotalOrderCount();
}
