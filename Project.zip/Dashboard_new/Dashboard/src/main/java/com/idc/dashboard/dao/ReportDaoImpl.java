package com.idc.dashboard.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.idc.dashboard.model.OrderTypeAndCount;
import com.idc.dashboard.model.SRM_REQEUST;
import com.idc.dashboard.model.TotalOrderCount;

public class ReportDaoImpl implements ReportDao {
	
	DatabaseConnection db = new DatabaseConnection();
	
	SRM_REQEUST srm = new SRM_REQEUST();
	
	Connection con = db.getConnection();
	
	Statement st;
	
	int escl = 0;

	@Override
	public List<Object> getReportsAll() {
		// TODO Auto-generated method stub
		ResultSet rs;
		List<Object> data = new ArrayList<Object>();
		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT COUNT_ACT,COUNT_QUE FROM S_SRM_REQUEST;");
			while (rs.next()) {
			srm.setActive(Integer.parseInt(rs.getString("COUNT_ACT")));
			srm.setQueued(Integer.parseInt(rs.getString("COUNT_QUE")));
			}
			
			rs = st.executeQuery("SELECT pending, pending_asset, open_payment from S_ORDER;");
			rs.next();
			int pending = Integer.parseInt(rs.getString("pending"));
			int pend_ass = Integer.parseInt(rs.getString("pending_asset"));
			int open_pay = Integer.parseInt(rs.getString("open_payment"));
			
			rs = st.executeQuery("SELECT COUNT_REAL AS COUNT FROM S_ESCL_REQ;");
			rs.next();
			escl = Integer.parseInt(rs.getString("COUNT"));
			
			
			data.add(escl);
			data.add(srm.getActive());
			data.add(pending);
			data.add(pend_ass);
			data.add(open_pay);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
	}

	@Override
	public OrderTypeAndCount getCountBasedOnOrderType() {
		// TODO Auto-generated method stub
		OrderTypeAndCount orderTypeAndCount = new OrderTypeAndCount();
		try {
			List<String> orderType = new ArrayList<String>();
			List<Integer> orderCount = new ArrayList<Integer>();
			st = con.createStatement();
			ResultSet rs = st.executeQuery("SELECT ORDER_TYPE, COUNT_ORDER FROM S_ORDER_ITEM;");
			while (rs.next()) {
				orderType.add(rs.getString("ORDER_TYPE"));
				orderCount.add(Integer.parseInt(rs.getString("COUNT_ORDER")));
			}
			orderTypeAndCount.setOrderType(orderType);
			orderTypeAndCount.setOrderCount(orderCount);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return orderTypeAndCount;
	}

	@Override
	public TotalOrderCount getTotalOrderCount() {
		// TODO Auto-generated method stub
		List<String> date = new ArrayList<String>();
		List<Integer> count = new ArrayList<Integer>();
		TotalOrderCount totalOrderCount = new TotalOrderCount();
		try {
			st = con.createStatement();
			ResultSet rs = st.executeQuery("SELECT DATE_FORMAT(ORDER_DATE,'%m-%d') AS DAY_COUNT, COUNT FROM ORDER_TRACK;");
			while (rs.next()) {
				date.add(rs.getString("DAY_COUNT"));
				count.add(Integer.parseInt(rs.getString("COUNT")));
			}
			totalOrderCount.setDate(date);
			totalOrderCount.setCount(count);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return totalOrderCount;
	}
	

}
