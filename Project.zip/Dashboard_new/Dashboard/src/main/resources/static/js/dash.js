/**
 * 
 */

$(document).ready(function(){
	$.ajax({                                                                   
	    type: "POST",
        contentType : "application/json",
	    url: "/api/reports",
	    cache: false,
	    data: {"success" : "OK"},
	    success: function(response) {
	    	var ord = response[0];
	    	var order_Type = response[1];
	    	var totalOrderCount = response[2];
	    	var data = {
		            labels: ['S_ESCL', 'S_SRM', 'Pend-Open Order', 'Pending Asset', 'Open Payment'],//['Jan', 'Feb', 'Mar', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
		            series: [
		                ord
		            ]
		        };
		
		        var options = {
		            seriesBarDistance: 10,
		            axisX: {
		                showGrid: false
		            },
		            height: "245px"
		        };
		
		        var responsiveOptions = [
		            ['screen and (max-width: 640px)', {
		                seriesBarDistance: 5,
		                axisX: {
		                    labelInterpolationFnc: function(value) {
		                        return value[0];
		                    }
		                }
		            }]
		        ];
		
		        var chartActivity = Chartist.Bar('#chartActivity', data, options, responsiveOptions);
		        
		        var ord_data = {
			            labels: order_Type.orderType,
			            series: [order_Type.orderCount]				            
			        };
		        /*Chartist.Pie('#chartPreferences', {
		            labels: orderType.orderType,
		            series: orderType.orderCount
		        });*/
		        var chartActivity = Chartist.Bar('#chartPreferences', ord_data, options, responsiveOptions);
		        
		        var dataSales = {
			            labels: totalOrderCount.date,
			            series: [totalOrderCount.count]
			        };
		        
		        var optionsSales = {
			            lineSmooth: false,
			            /*low: 0,
			            high: 800,*/
			            showArea: true,
			            height: "245px",
			            axisX: {
			                showGrid: false,
			            },
			            lineSmooth: Chartist.Interpolation.simple({
			                divisor: 3
			            }),
			            showLine: false,
			            showPoint: false,
			            fullWidth: false
			        };
			
			        var responsiveSales = [
			            ['screen and (max-width: 640px)', {
			                axisX: {
			                    labelInterpolationFnc: function(value) {
			                        return value[0];
			                    }
			                }
			            }]
			        ];
			
			        var chartHours = Chartist.Line('#chartHours', dataSales, optionsSales, responsiveSales);
	    	
	    },
	    error: function(e) {
	        alert("Error while saving filters: " + e.message);
	    }
	});
	$('a.refresh').click(function(e){
		e.preventDefault();
		$.ajax({                                                                   
		    type: "POST",
	        contentType : "application/json",
		    url: "/api/reports",
		    cache: false,
		    data: {"success" : "OK"},
		    success: function(response) {
		    	var ord = response[0];
		    	var order_Type = response[1];
		    	var totalOrderCount = response[2];
		    	var data = {
			            labels: ['S_ESCL', 'S_SRM', 'Pend-Open Order', 'Pending Asset', 'Open Payment'],//['Jan', 'Feb', 'Mar', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
			            series: [
			                ord
			            ]
			        };
			
			        var options = {
			            seriesBarDistance: 10,
			            axisX: {
			                showGrid: false
			            },
			            height: "245px"
			        };
			
			        var responsiveOptions = [
			            ['screen and (max-width: 640px)', {
			                seriesBarDistance: 5,
			                axisX: {
			                    labelInterpolationFnc: function(value) {
			                        return value[0];
			                    }
			                }
			            }]
			        ];
			
			        var chartActivity = Chartist.Bar('#chartActivity', data, options, responsiveOptions);
			        
			        var ord_data = {
				            labels: order_Type.orderType,
				            series: [order_Type.orderCount]				            
				        };
			        Chartist.Pie('#chartPreferences', {
			            labels: orderType.orderType,
			            series: orderType.orderCount
			        });
			        var chartActivity = Chartist.Bar('#chartPreferences', ord_data, options, responsiveOptions);
			        
			        var dataSales = {
				            labels: totalOrderCount.date,
				            series: [totalOrderCount.count]
				        };
			        
			        var optionsSales = {
				            lineSmooth: false,
				            low: 0,
				            high: 800,
				            showArea: true,
				            height: "245px",
				            axisX: {
				                showGrid: false,
				            },
				            lineSmooth: Chartist.Interpolation.simple({
				                divisor: 3
				            }),
				            showLine: false,
				            showPoint: false,
				            fullWidth: false
				        };
				
				        var responsiveSales = [
				            ['screen and (max-width: 640px)', {
				                axisX: {
				                    labelInterpolationFnc: function(value) {
				                        return value[0];
				                    }
				                }
				            }]
				        ];
				
				        var chartHours = Chartist.Line('#chartHours', dataSales, optionsSales, responsiveSales);
		    	
		    },
		    error: function(e) {
		        alert("Error while saving filters: " + e.message);
		    }
		});
	})
	
	demo = {	
		initDashboardPageCharts: function() {
			
			
	        var dataPreferences = {
	            series: [
	                [25, 30, 20, 25]
	            ]
	        };
	
	        var optionsPreferences = {
	            donut: true,
	            donutWidth: 40,
	            startAngle: 0,
	            total: 100,
	            showLabel: false,
	            axisX: {
	                showGrid: false
	            }
	        };
	
	        //Chartist.Pie('#chartPreferences', dataPreferences, optionsPreferences);
	

	
	
	       
	
	        // var optionsSales = {
	        //   lineSmooth: false,
	        //   low: 0,
	        //   high: 800,
	        //    chartPadding: 0,
	        //   showArea: true,
	        //   height: "245px",
	        //   axisX: {
	        //     showGrid: false,
	        //   },
	        //   axisY: {
	        //     showGrid: false,
	        //   },
	        //   lineSmooth: Chartist.Interpolation.simple({
	        //     divisor: 6
	        //   }),
	        //   showLine: false,
	        //   showPoint: true,
	        //   fullWidth: true
	        // };
	        
	
	        // lbd.startAnimationForLineChart(chartHours);
	
	        
	    }
	}
});